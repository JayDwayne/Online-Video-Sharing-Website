#online-video-sharing-website
Youtube and Vimeo are the examples of Online Video Sharing Website and In this project, I create a Website like this inline with the same concept.
